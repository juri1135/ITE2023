/**
 * 
 */
/**
 * @author USER
 *
 */
module Quiz2 {
}