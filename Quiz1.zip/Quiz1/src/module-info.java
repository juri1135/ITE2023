/**
 * 
 */
/**
 * @author USER
 *
 */
module Quiz1 {
}