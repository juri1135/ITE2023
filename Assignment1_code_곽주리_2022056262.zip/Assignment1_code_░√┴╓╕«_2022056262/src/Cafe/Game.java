package Cafe;

public class Game {
	private String name;
	private String quality; //bad, okay, good
	private double price;
	public Game(String name, double price) {
		this.name=name;
		quality="good";
		this.price=price;
	}
	public String toString() {
		return ("Name: "+name+", Quality: "+quality+", Price: "+price+".");
	}
	public double getRepairCost() {
		if(quality=="bad") {
			return (0.5*price);
		}
		else if(quality=="okay") {
			return (0.2*price);
		}
		else {
			return 0.0;
		}
	}
	public void repair() {
		quality="good";
	}
	public void lowerQuality() {
		if(quality=="good") quality="okay";
		else if(quality=="okay") quality="bad";
	}
	public String getname() {
		return name;
	}
	public String getquality() {
		return quality;
	}
	public double getprice() {
		return price;
	}
}
