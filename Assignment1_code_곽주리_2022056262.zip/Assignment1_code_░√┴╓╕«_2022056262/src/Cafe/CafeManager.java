package Cafe;
import java.util.Scanner;
public class CafeManager {

	public static void main(String[] args) {
		Scanner keyboard=new Scanner(System.in);
		Game[] games=new Game[3];
		games[0]=new Game("Uno",7.0);
		games[1]=new Game("Battleship",4.25);
		games[2]=new Game("Monopoly",12.0);
		Cafe cafe=new Cafe(games,25.0);
		cafe.printCafeDetails();
		int inpu=0;
		while(inpu!=5) {
			System.out.println("What would you like to do:");
			System.out.println("1: Rent a game, 2: return a game, 3: repair a game, 4: Buy a new game, 5: close the cafe ");
			inpu=keyboard.nextInt();
			if(inpu==1) {
				String name;
				System.out.println("Which game would you like to rent?");
				name=keyboard.next();
				cafe.rentOutGame(name);
			}
			else if(inpu==2) {
				String name;
				System.out.println("Which game would you like to return?");
				name=keyboard.next();
				cafe.returnGame(name);
			}
			else if(inpu==3) {
				String name;
				System.out.println("Which game would you like to repair?");
				name=keyboard.next();
				cafe.repairGame(name);
			}
			else if(inpu==4) {
				String name;
				double p;
				System.out.println("What is the name of the game?");
				name=keyboard.next();
				System.out.println("What is the price of the game?");
				p=keyboard.nextDouble();
				Game game=new Game(name,p);
				cafe.buyGame(game);
			}
		}
		System.out.println("Closed");
	}
}
