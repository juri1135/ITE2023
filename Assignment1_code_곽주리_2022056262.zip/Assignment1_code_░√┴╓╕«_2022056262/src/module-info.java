/**
 * 
 */
/**
 * @author USER
 *
 */
module Assignment1_code_곽주리_2022056262 {
}